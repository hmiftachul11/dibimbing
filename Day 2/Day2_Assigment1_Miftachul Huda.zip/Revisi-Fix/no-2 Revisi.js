// Buat algoritma FlowChart dan Pseudecode  untuk menghitung faktorial suatu bilangan.

// Pseudocode PROGRAM faktorial

// DEKLARASI
// var number : integer
// var factorial : integer

// ALGORITMA:
// INPUT number
// factorial = 1
// FOR i = 1 TO number
//   factorial = factorial * i
//   i = i + 1  
// OUTPUT factorial

// AKHIR PROGRAM


