// Buat algoritma FlowChart dan Pseudecode  sederhana untuk menghitung jumlah huruf vokal dalam sebuah string.

// PSEUDOCODE sederhana untuk menghitung jumlah huruf vokal dalam sebuah string.

// DEKLARASI
// vocal = ['a', 'i', 'u', 'e', 'o']
// result = ''
// input = 'makan'

// ALGORITMA:
// FOR EACH character IN input
//   FOR EACH vowel IN vocal
//     IF character EQUALS vowel
//       THEN result = result + character
//     END IF
//   END FOR
// END FOR

// OUTPUT LENGTH OF result

